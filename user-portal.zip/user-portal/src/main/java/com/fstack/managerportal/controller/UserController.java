package com.fstack.managerportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fstack.managerportal.model.User;
import com.fstack.managerportal.service.UserService;

@RequestMapping({"/users"})
@RestController
//@RequestMapping({"/api"})

public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public User create(@RequestBody User user){
        return userService.create(user);
    }

    @GetMapping(path = {"/{id}"})
    public User findOne(@PathVariable("id") int id){
        return userService.findById(id);
    }

    @PutMapping
    public User update(@RequestBody User user){
        return userService.update(user);
    }

    @DeleteMapping(path ={"/{id}"})
    public User delete(@PathVariable("id") int id) {
        return userService.delete(id);
    }

    @GetMapping
    @RequestMapping({"/userList"})
    public List<User> findAll(){
        List<User> list = userService.findAll();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
    
    @GetMapping
    @RequestMapping({"/sortUserListByFirstName"})
    public List<User> sortUserListByFirstName(){
        List<User> list = userService.sortByFirstName();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
    
    @GetMapping
    @RequestMapping({"/sortUserListByLastName"})
    public List<User> sortUserListByLastName(){
        List<User> list = userService.sortByLastName();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
    
    @GetMapping
    @RequestMapping({"/sortUserListByEmployeeId"})
    public List<User> sortUserListByEmployeeId(){
        List<User> list = userService.sortByEmployeeId();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
}
