package com.fstack.managerportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fstack.managerportal.model.Project;
import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.service.ProjectService;

@RequestMapping({"/projects"})
@RestController
//@RequestMapping({"/api"})

public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @PostMapping
    public Project create(@RequestBody Project project){
    	System.out.println(project.getProjectName() + project.getStartDate() + project.getEndDate() + project.getPriority());
        return projectService.create(project);
    }

    @GetMapping(path = {"/{id}"})
    public Project findOne(@PathVariable("id") int id){
        return projectService.findById(id);
    }
    
    @GetMapping
    @RequestMapping({"/sortTasksByStartDate/{id}"})
    public Project sortTasksByStartDate(@PathVariable("id") int id){
        Project project = projectService.sortTasksByStartDate(id);
        return project;
        
    }
    @GetMapping
    @RequestMapping({"/sortTasksByEndDate/{id}"})
    public Project sortTasksByEndDate(@PathVariable("id") int id){
        Project project = projectService.sortTasksByEndDate(id);
        return project;
        
    }
    
    @GetMapping
    @RequestMapping({"/sortTasksByPriority/{id}"})
    public Project sortTasksByPriority(@PathVariable("id") int id){
        Project project = projectService.sortTasksByPriority(id);
        return project;
        
    }

    @PutMapping
    public Project update(@RequestBody Project project){
        return projectService.update(project);
    }


    @GetMapping
    @RequestMapping({"/projectList"})
    public List<Project> findAll(){
        List<Project> list = projectService.findAll();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
    
    @GetMapping
    @RequestMapping({"/sortProjectByStartDate"})
    public List<Project> sortProjectByStartDate(){
        List<Project> list = projectService.sortProjectByStartDate();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
    
    @GetMapping
    @RequestMapping({"/sortProjectByEndDate"})
    public List<Project> sortProjectByEndDate(){
        List<Project> list = projectService.sortProjectByEndDate();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
    
    @GetMapping
    @RequestMapping({"/sortProjectByPriority"})
    public List<Project> sortProjectByPriority(){
        List<Project> list = projectService.sortProjectByPriority();
        System.out.println("-------------->" + list.size());
        return list;
        
    }
}
