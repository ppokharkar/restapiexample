package com.fstack.managerportal.service;

import java.util.List;

import com.fstack.managerportal.model.Project;
import com.fstack.managerportal.model.Task;

public interface ProjectService {

    Project create(Project project);

    List<Project> findAll();

    Project findById(int id);

    Project update(Project project);
    
    List<Project> sortProjectByStartDate();
    
    List<Project> sortProjectByEndDate();

    List<Project> sortProjectByPriority();

	Project sortTasksByStartDate(int projectId);
	
	Project sortTasksByEndDate(int projectId);
	
	Project sortTasksByPriority(int projectId);


}
