package com.fstack.managerportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fstack.managerportal.model.ParentTask;
import com.fstack.managerportal.service.ParentTaskService;

@RequestMapping({"/parenttasks"})
@RestController
public class ParentTaskController {
  @Autowired
  public ParentTaskService parentTaskService;
  
  

  @PostMapping
  public ParentTask create(@RequestBody ParentTask parentTask){
      return parentTaskService.add(parentTask);
  }


  @PutMapping
  public ParentTask update(@RequestBody ParentTask parentTask){
      return parentTaskService.updateParentTask(parentTask);
  }


  @GetMapping
  @RequestMapping({"/parenttaskList"})
  public List<ParentTask> findAll(){
      List<ParentTask> list = parentTaskService.getAllParentTask();
      System.out.println("-------------->" + list.size());
      return list;
  }
  
  
  
}
