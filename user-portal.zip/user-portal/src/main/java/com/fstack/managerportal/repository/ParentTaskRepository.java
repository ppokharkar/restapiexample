package com.fstack.managerportal.repository;

import java.util.List;

import org.springframework.data.repository.Repository;

import com.fstack.managerportal.model.ParentTask;

public interface ParentTaskRepository extends Repository<ParentTask, Integer> {

    List<ParentTask> findAll();

    ParentTask save(ParentTask task);
}
