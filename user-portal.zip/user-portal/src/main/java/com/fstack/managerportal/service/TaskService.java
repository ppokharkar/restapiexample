package com.fstack.managerportal.service;

import java.util.List;

import com.fstack.managerportal.model.Task;

public interface TaskService {

  Task add(Task task);
  
  List<Task>  getAllTask();
  
  Task updateTask(Task task);
  
  List<Task> sortTaskByStartDate();
  
  List<Task> sortTaskByEndDate();

  List<Task> sortTaskByPriority();
  
  List<Task> sortTaskByCompletedStatus();

}
