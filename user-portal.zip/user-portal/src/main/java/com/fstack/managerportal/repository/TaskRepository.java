package com.fstack.managerportal.repository;

import java.util.List;

import org.springframework.data.repository.Repository;

import com.fstack.managerportal.model.Task;

public interface TaskRepository extends Repository<Task, Integer> {

    void delete(Task task);

    List<Task> findAll();

    Task findOne(int id);

    Task save(Task task);
}
