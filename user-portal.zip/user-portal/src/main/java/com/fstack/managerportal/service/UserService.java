package com.fstack.managerportal.service;

import java.util.List;

import com.fstack.managerportal.model.User;

public interface UserService {

    User create(User user);

    User delete(int id);

    List<User> findAll();

    User findById(int id);

    User update(User user);
    
    List<User> sortByFirstName();
    
    List<User> sortByLastName();

    List<User> sortByEmployeeId();


}
