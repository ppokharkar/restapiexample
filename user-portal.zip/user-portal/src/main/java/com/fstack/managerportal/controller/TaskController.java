package com.fstack.managerportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.service.ProjectService;
import com.fstack.managerportal.service.TaskService;

@RequestMapping({"/tasks"})
@RestController
public class TaskController {
  @Autowired
  public TaskService taskService;
  
  @Autowired
  public ProjectService projectService;
  
  

  @PostMapping
  public Task create(@RequestBody Task task){
      return taskService.add(task);
  }


  @PutMapping
  public Task update(@RequestBody Task task){
      return taskService.updateTask(task);
  }


  @GetMapping
  @RequestMapping({"/taskList"})
  public List<Task> findAll(){
      List<Task> list = taskService.getAllTask();
      System.out.println("-------------->" + list.size());
      return list;
  }
  
  
  @GetMapping
  @RequestMapping({"/sortTaskByEndDate"})
  public List<Task> sortTaskByEndDate(){
      List<Task> list = taskService.sortTaskByEndDate();
      System.out.println("-------------->" + list.size());
      return list;
      
  }
  
  @GetMapping
  @RequestMapping({"/sortTaskByPriority"})
  public List<Task> sortTaskByPriority(){
      List<Task> list = taskService.sortTaskByPriority();
      System.out.println("-------------->" + list.size());
      return list;
      
  }
  
  @GetMapping
  @RequestMapping({"/sortTaskByCompletedStatus"})
  public List<Task> sortTaskByCompletedStatus(){
      List<Task> list = taskService.sortTaskByCompletedStatus();
      System.out.println("-------------->" + list.size());
      return list;
      
  }
}
