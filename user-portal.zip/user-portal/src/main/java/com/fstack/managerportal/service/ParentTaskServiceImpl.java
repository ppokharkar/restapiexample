package com.fstack.managerportal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fstack.managerportal.model.ParentTask;
import com.fstack.managerportal.repository.ParentTaskRepository;

@Service("parentTaskService")
public class ParentTaskServiceImpl implements ParentTaskService {


  @Autowired
 ParentTaskRepository parentTaskRepository;
  
  public void setParentTaskRepository(ParentTaskRepository parentTaskRepository) {
	this.parentTaskRepository = parentTaskRepository;
}

public void setTaskRepository(ParentTaskRepository parentTaskRepository) {
    this.parentTaskRepository = parentTaskRepository;
  }

  @Override
  public ParentTask add(ParentTask parentTask) {
   return parentTaskRepository.save(parentTask);
  }

  @Override
  public List<ParentTask> getAllParentTask() {
    return (List<ParentTask>) parentTaskRepository.findAll();
  }

  @Override
  public ParentTask updateParentTask(ParentTask parentTask) {
    return parentTaskRepository.save(parentTask);    
  }

}
