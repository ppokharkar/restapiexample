package com.fstack.managerportal.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="project")
public class Project {
  
  public Project() {
    
  }
  
  @Id
  @Column(name = "Project_ID", nullable = false)
  int projectId;
  public int getProjectId() {
    return projectId;
  }
  public void setProjectId(int projectId) {
    this.projectId = projectId;
  }
  public String getProjectName() {
    return projectName;
  }
  public void setProject(String projectName) {
    this.projectName = projectName;
  }
  public Date getStartDate() {
    return startDate;
  }
  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }
  public Date getEndDate() {
    return endDate;
  }
  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }
  public int getPriority() {
    return priority;
  }
  public void setPriority(int priority) {
    this.priority = priority;
  }
  
  
  public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}

@Column(name = "Project")
  String projectName;
  @Column(name = "Start_Date")
  Date startDate;
  @Column(name = "End_Date")
  Date endDate;
  @Column(name = "priority")
  int priority;
  @Column(name = "user_id")
  int userId;
  
 /* @OneToMany(mappedBy="project",cascade=CascadeType.ALL, fetch = FetchType.EAGER)
  Set<User> user;
  public Set<User> getUser() {
    return user;
  }
  public void setUser(Set<User> user) {
    this.user = user;
  }*/
  
  //@JsonManagedReference
  @OneToMany(mappedBy="project",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
  List<Task> task;
  public List<Task> getTask() {
    return task;
  }
  public void setTask(List<Task> task) {
    this.task = task;
  }

}
