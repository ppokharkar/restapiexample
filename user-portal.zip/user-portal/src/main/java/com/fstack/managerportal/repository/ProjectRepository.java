package com.fstack.managerportal.repository;

import java.util.List;

import org.springframework.data.repository.Repository;

import com.fstack.managerportal.model.Project;

public interface ProjectRepository extends Repository<Project, Integer> {

    void delete(Project project);

    List<Project> findAll();

    Project findOne(int id);

    Project save(Project project);
}
