package com.fstack.managerportal.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="parenttask")
public class ParentTask {
  
  @Id
  @Column(name = "parentId", nullable = false)
  int parentId;
  @Column(name = "parentTask")
  String parentTask;
  //@JsonManagedReference
  @OneToMany(mappedBy="parentTask",cascade=CascadeType.ALL, fetch = FetchType.LAZY)
  private List<Task> task;
  public List<Task> getTask() {
    return task;
  }
  public void setTask(List<Task> task) {
    this.task = task;
  }
  public int getParentId() {
    return parentId;
  }
  public void setParentId(int parentId) {
    this.parentId = parentId;
  }
  public String getParentTask() {
    return parentTask;
  }
  public void setParentTask(String parentTask) {
    this.parentTask = parentTask;
  }
}
