package com.fstack.managerportal.service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fstack.managerportal.model.Project;
import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectRepository repository;

    public void setRepository(ProjectRepository repository) {
		this.repository = repository;
	}

	@Override
    public Project create(Project project) {
        return repository.save(project);
    }

    @Override
    public List<Project> findAll() {
        return repository.findAll();
    }

    @Override
    public Project findById(int id) {
        return repository.findOne(id);
    }

    @Override
    public Project update(Project project) {
        return repository.save(project);
    }

	@Override
	public List<Project> sortProjectByStartDate() {
		 List<Project> list = repository.findAll();
	     return list.stream().sorted(Comparator.comparing(Project::getStartDate)).collect(Collectors.toList());

	}
	

	@Override
	public List<Project> sortProjectByEndDate() {
		 List<Project> list = repository.findAll();
	     return list.stream().sorted(Comparator.comparing(Project::getEndDate)).collect(Collectors.toList());
	}

	@Override
	public List<Project> sortProjectByPriority() {
		 List<Project> list = repository.findAll();
	     return list.stream().sorted(Comparator.comparing(Project::getPriority)).collect(Collectors.toList());
	}

	@Override
	public Project sortTasksByStartDate(int projectId) {
		 Project project = repository.findOne(projectId);
	     List<Task> task = project.getTask().stream().sorted(Comparator.comparing(Task::getStartDate)).collect(Collectors.toList());
	     project.setTask(task);
	     return project;

	}

	@Override
	public Project sortTasksByEndDate(int projectId) {
		 Project project = repository.findOne(projectId);
	     List<Task> task = project.getTask().stream().sorted(Comparator.comparing(Task::getEndDate)).collect(Collectors.toList());
	     project.setTask(task);
	     return project;
	}

	@Override
	public Project sortTasksByPriority(int projectId) {
		 Project project = repository.findOne(projectId);
	     List<Task> task = project.getTask().stream().sorted(Comparator.comparing(Task::getPriority)).collect(Collectors.toList());
	     project.setTask(task);
	     return project;
	}
}
