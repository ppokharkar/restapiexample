package com.fstack.managerportal.service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.repository.TaskRepository;

@Service("taskService")
public class TaskServiceImpl implements TaskService {


  @Autowired
 TaskRepository taskRepository;
  
  public void setTaskRepository(TaskRepository taskRepository) {
    this.taskRepository = taskRepository;
  }

  @Override
  public Task add(Task task) {
   return taskRepository.save(task);
  }

  @Override
  public List<Task> getAllTask() {
    return (List<Task>) taskRepository.findAll();
  }

  @Override
  public Task updateTask(Task task) {
    return taskRepository.save(task);    
  }

	@Override
	public List<Task> sortTaskByStartDate() {
		 List<Task> list = taskRepository.findAll();
	     return list.stream().sorted(Comparator.comparing(Task::getStartDate)).collect(Collectors.toList());
	}
	
	@Override
	public List<Task> sortTaskByEndDate() {
		 List<Task> list = taskRepository.findAll();
	     return list.stream().sorted(Comparator.comparing(Task::getEndDate)).collect(Collectors.toList());
	}
	
	@Override
	public List<Task> sortTaskByPriority() {
		 List<Task> list = taskRepository.findAll();
	     return list.stream().sorted(Comparator.comparing(Task::getPriority)).collect(Collectors.toList());
	}
	
	@Override
	public List<Task> sortTaskByCompletedStatus() {
		 List<Task> list = taskRepository.findAll();
	     return list.stream().sorted(Comparator.comparing(Task::getStatus)).collect(Collectors.toList());
	}


}
