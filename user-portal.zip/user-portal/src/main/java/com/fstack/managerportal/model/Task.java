package com.fstack.managerportal.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="task")
public class Task {
  
  public int getTaskId() {
    return taskId;
  }
  public void setTaskId(int taskId) {
    this.taskId = taskId;
  }
  public String getTaskName() {
    return taskName;
  }
  public void setTaskName(String taskName) {
    this.taskName = taskName;
  }
  public Date getStartDate() {
    return startDate;
  }
  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }
  public Date getEndDate() {
    return endDate;
  }
  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }
  public int getPriority() {
    return priority;
  }
  public void setPriority(int priority) {
    this.priority = priority;
  }
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }
  @Id
  @Column(name = "task_id", nullable = false)
  int taskId;
  @Column(name = "task")
  String taskName;
  @Column(name = "start_date")
  Date startDate;
  @Column(name = "end_date")
  Date endDate;
  @Column(name = "priority")
  int priority;
  @Column(name = "status")
  String status;
  
  //@JsonBackReference
  @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
  @JoinColumn(name = "ProjectID")
  private Project project;
  @JsonIgnore
  public Project getProject() {
    return project;
  }
  @JsonIgnore
  public void setProject(Project project) {
    this.project = project;
  }
  
  //@JsonBackReference
  @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL)
  @JoinColumn(name = "Parent_ID")
  private ParentTask parentTask;
  
  @JsonIgnore
  public ParentTask getParentTask() {
	return parentTask;
  }
  @JsonIgnore
  public void setParentTask(ParentTask parentTask) {
	this.parentTask = parentTask;
  }
}
