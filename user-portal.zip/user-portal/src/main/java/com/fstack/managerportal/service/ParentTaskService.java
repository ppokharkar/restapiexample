package com.fstack.managerportal.service;

import java.util.List;

import com.fstack.managerportal.model.ParentTask;

public interface ParentTaskService {

  ParentTask add(ParentTask parentTask);
  
  List<ParentTask>  getAllParentTask();
  
  ParentTask updateParentTask(ParentTask parentTask);
  
}
