package com.fstack.managerportal.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fstack.managerportal.model.Project;
import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.model.User;
import com.fstack.managerportal.repository.ProjectRepository;

import junit.framework.Assert;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ProjectServiceTest {
	@InjectMocks
	private ProjectServiceImpl projectServiceImpl;

	@Mock
	ProjectRepository projectRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("deprecation")

	@Test
	public void saveProject() throws ParseException {
		Mockito.mock(ProjectServiceImpl.class);

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);
		project.setProject("ADD");

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(12);
		task.setTaskName("Dev");
		task.setStatus("Completed");

		List<Task> list = new ArrayList<Task>();
		list.add(0,task);
		project.setTask(list);

		Mockito.when(projectServiceImpl.create(project)).thenReturn(project);
		Assert.assertEquals(1, project.getProjectId());
		Assert.assertEquals(12, project.getPriority());
		Assert.assertEquals(1, project.getUserId());
		Assert.assertEquals("ADD", project.getProjectName());
		Assert.assertEquals(12, project.getTask().get(0).getPriority());

	}

	@Test
	public void updateProject() throws ParseException {
		Mockito.mock(ProjectServiceImpl.class);

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);

		Mockito.when(projectServiceImpl.update(project)).thenReturn(project);
		Assert.assertEquals(1, project.getProjectId());
		Assert.assertEquals(12, project.getPriority());
	}

	@Test
	public void getAllProject() throws ParseException {
		Mockito.mock(ProjectServiceImpl.class);

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);

		List<Project> list = new ArrayList<Project>();
		list.add(project);

		Mockito.when(projectServiceImpl.findAll()).thenReturn(list);
		Assert.assertEquals(1, list.get(0).getProjectId());
		Assert.assertEquals(12, list.get(0).getPriority());
	}

	@Test
	public void getSingleProject() throws ParseException {
		Mockito.mock(ProjectServiceImpl.class);

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);

		Mockito.when(projectServiceImpl.findById(1)).thenReturn(project);
		Assert.assertEquals(1, project.getProjectId());
		Assert.assertEquals(12, project.getPriority());
	}

	@Test
	public void sortProjectByStartDate() throws ParseException {
		Mockito.mock(ProjectServiceImpl.class);

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);
		project.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"));

		Project projectNext = new Project();
		projectNext.setProjectId(1);
		projectNext.setPriority(12);
		projectNext.setUserId(1);
		projectNext.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"));

		List<Project> list = new ArrayList<Project>();
		list.add(0, project);
		list.add(1, projectNext);

		System.out.println(list.size());

		Mockito.when(projectServiceImpl.sortProjectByStartDate()).thenReturn(list);
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"), list.get(0).getStartDate());
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"), list.get(1).getStartDate());
	}

	@Test
	public void sortProjectByEndDate() throws ParseException {
		Mockito.mock(ProjectServiceImpl.class);

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);
		project.setEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"));

		Project projectNext = new Project();
		projectNext.setProjectId(1);
		projectNext.setPriority(12);
		projectNext.setUserId(1);
		projectNext.setEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"));

		List<Project> list = new ArrayList<Project>();
		list.add(0, project);
		list.add(1, projectNext);

		System.out.println(list.size());

		Mockito.when(projectServiceImpl.sortProjectByEndDate()).thenReturn(list);
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"), list.get(0).getEndDate());
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"), list.get(1).getEndDate());
	}

	@Test
	public void sortProjectByPriority() throws ParseException {
		Mockito.mock(ProjectServiceImpl.class);

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);

		Project projectNext = new Project();
		projectNext.setProjectId(1);
		projectNext.setPriority(13);
		projectNext.setUserId(1);

		List<Project> list = new ArrayList<Project>();
		list.add(0, project);
		list.add(1, projectNext);

		System.out.println(list.size());

		Mockito.when(projectServiceImpl.sortProjectByPriority()).thenReturn(list);
		Assert.assertEquals(12, list.get(0).getPriority());
		Assert.assertEquals(13, list.get(1).getPriority());
	}

}
