package com.fstack.managerportal.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.fstack.managerportal.model.Project;
import com.fstack.managerportal.model.User;
import com.fstack.managerportal.repository.ProjectRepository;
import com.fstack.managerportal.service.ProjectServiceImpl;

public class ProjectRepoTest {
  
  
  private ProjectServiceImpl projectServiceImplMock;

  private ProjectRepository projectRepositoryMock;

  @Before
  public void setUp() {
	projectServiceImplMock = new ProjectServiceImpl();
	projectRepositoryMock = mock(ProjectRepository.class);
	projectServiceImplMock.setRepository(projectRepositoryMock);
  }
  
  @Test
  public void create() throws ParseException {
    
    Project project = new Project();
    project.setProjectId(1);
    project.setPriority(12);
    project.setUserId(1);
    
    
    when(projectRepositoryMock.save(any(Project.class))).thenReturn(project);
    
    Project returned = projectServiceImplMock.create(project);
    verify(projectRepositoryMock, times(1)).save(project);

    assertEquals(project, returned);

    
  }

  @Test
  public void findById() throws ParseException {
    
	    Project project = new Project();
	    project.setProjectId(1);
	    project.setPriority(12);
	    project.setUserId(1);

    
      when(projectRepositoryMock.findOne(1)).thenReturn(project);
      
      Project returned = projectRepositoryMock.findOne(1);
      
      verify(projectRepositoryMock, times(1)).findOne(1);
      verifyNoMoreInteractions(projectRepositoryMock);
      
      assertEquals(project, returned);
  }
  

  @Test
  public void findAll() throws ParseException {

	    Project project = new Project();
	    project.setProjectId(1);
	    project.setPriority(12);
	    project.setUserId(1);
		
		List<Project> list = new ArrayList<Project>();
		list.add(project);

    
      when(projectRepositoryMock.findAll()).thenReturn(list);
      
      List<Project> returned = projectServiceImplMock.findAll();
      
      verify(projectRepositoryMock, times(1)).findAll();
      verifyNoMoreInteractions(projectRepositoryMock);
      
      assertEquals(list, returned);
  }
  
  
  

}
