package com.fstack.managerportal.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fstack.managerportal.model.Project;
import com.fstack.managerportal.model.User;
import com.fstack.managerportal.repository.UserRepository;

import junit.framework.Assert;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class UserServiceTest {
  @InjectMocks
   private UserServiceImpl userServiceImpl;
  
  @Mock
  UserRepository userRepository;
  
  @Before
  public void init() {
      MockitoAnnotations.initMocks(this);
  }
   
   @SuppressWarnings("deprecation")

   @Test
   public void saveUser() throws ParseException {
     Mockito.mock(UserServiceImpl.class);
     User user = new User();
     user.setId(1);
     user.setEmployeeId(1);
     user.setFirstName("Pandurang");
     user.setLastName("Pokharkar");
     
      Mockito.when(userServiceImpl.create(user)).thenReturn(user);
      Assert.assertEquals("Pandurang", user.getFirstName());
      Assert.assertEquals("Pokharkar", user.getLastName());
   }
   
   
   @Test
   public void updateUser() throws ParseException {
     Mockito.mock(UserServiceImpl.class);
     User user = new User();
     user.setId(1);
     user.setEmployeeId(1);
     user.setFirstName("Pandurang");
     user.setLastName("Pokharkar");
     
      Mockito.when(userServiceImpl.update(user)).thenReturn(user);
      Assert.assertEquals("Pandurang", user.getFirstName());
      Assert.assertEquals("Pokharkar", user.getLastName());
   }
   
   
   @Test
   public void getAllUser() throws ParseException {
     Mockito.mock(UserServiceImpl.class);
     User user = new User();
     user.setId(1);
     user.setEmployeeId(1);
     user.setFirstName("Pandurang");
     user.setLastName("Pokharkar");
     
     List<User> list = new ArrayList<User>();
     list.add(user);
     
      Mockito.when(userServiceImpl.findAll()).thenReturn(list);
      Assert.assertEquals("Pandurang", list.get(0).getFirstName());
      Assert.assertEquals("Pokharkar", list.get(0).getLastName());
   }
   
   
   @Test
   public void getSingleUser() throws ParseException {
     Mockito.mock(UserServiceImpl.class);
     User user = new User();
     user.setId(1);
     user.setEmployeeId(1);
     user.setFirstName("Pandurang");
     user.setLastName("Pokharkar");
     
     
      Mockito.when(userServiceImpl.findById(1)).thenReturn(user);
      Assert.assertEquals("Pandurang", user.getFirstName());
      Assert.assertEquals("Pokharkar", user.getLastName());
   }
   
   
   @Test
   public void deleteUser() throws ParseException {
     Mockito.mock(UserServiceImpl.class);
     User user = new User();
     user.setId(1);
     user.setEmployeeId(1);
     user.setFirstName("Pandurang");
     user.setLastName("Pokharkar");
     
     
      Mockito.when(userServiceImpl.delete(1)).thenReturn(user);
      Assert.assertEquals("Pandurang", user.getFirstName());
      Assert.assertEquals("Pokharkar", user.getLastName());
   }
   
   @Test
   public void sortUserByFirstName() throws ParseException {
	    Mockito.mock(UserServiceImpl.class);

	     User user = new User();
	     user.setId(1);
	     user.setEmployeeId(1);
	     user.setFirstName("Sam");
	     user.setLastName("Adam");
	     
	     
	     User userNext = new User();
	     userNext.setId(1);
	     userNext.setEmployeeId(1);
	     userNext.setFirstName("Tame");
	     userNext.setLastName("Ray");
	     
	     
	     List<User> list = new ArrayList<User>();
	     list.add(0,user);
	     list.add(1,userNext);
	     
	     System.out.println(list.size());
	     
	      Mockito.when(userServiceImpl.sortByFirstName()).thenReturn(list);
	      Assert.assertEquals("Sam", list.get(0).getFirstName());
	      Assert.assertEquals("Tame", list.get(1).getFirstName());
   }
   
   
   @Test
   public void sortUserByLastName() throws ParseException {
	    Mockito.mock(UserServiceImpl.class);

	     User user = new User();
	     user.setId(1);
	     user.setEmployeeId(1);
	     user.setFirstName("Sam");
	     user.setLastName("Adam");
	     
	     
	     User userNext = new User();
	     userNext.setId(1);
	     userNext.setEmployeeId(1);
	     userNext.setFirstName("Tame");
	     userNext.setLastName("Ray");
	     
	     
	     List<User> list = new ArrayList<User>();
	     list.add(0,user);
	     list.add(1,userNext);
	     
	     System.out.println(list.size());
	     
	      Mockito.when(userServiceImpl.sortByLastName()).thenReturn(list);
	      Assert.assertEquals("Adam", list.get(0).getLastName());
	      Assert.assertEquals("Ray", list.get(1).getLastName());
   }
   
   
   @Test
   public void sortUserByEmployeeId() throws ParseException {
	    Mockito.mock(UserServiceImpl.class);

	     User user = new User();
	     user.setId(1);
	     user.setEmployeeId(1);
	     user.setFirstName("Sam");
	     user.setLastName("Adam");
	     
	     
	     User userNext = new User();
	     userNext.setId(1);
	     userNext.setEmployeeId(2);
	     userNext.setFirstName("Tame");
	     userNext.setLastName("Ray");
	     
	     
	     List<User> list = new ArrayList<User>();
	     list.add(0,user);
	     list.add(1,userNext);
	     
	     System.out.println(list.size());
	     
	      Mockito.when(userServiceImpl.sortByEmployeeId()).thenReturn(list);
	      Assert.assertEquals(1, list.get(0).getEmployeeId());
	      Assert.assertEquals(2, list.get(1).getEmployeeId());
   }
   
}
