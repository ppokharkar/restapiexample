package com.fstack.managerportal.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.fstack.managerportal.model.User;
import com.fstack.managerportal.repository.UserRepository;
import com.fstack.managerportal.service.UserServiceImpl;

public class UserRepoTest {
  
  
  private UserServiceImpl userServiceMock;

  private UserRepository userRepositoryMock;

  @Before
  public void setUp() {
	userServiceMock = new UserServiceImpl();
	userRepositoryMock = mock(UserRepository.class);
	userServiceMock.setRepository(userRepositoryMock);
  }
  
  @Test
  public void create() throws ParseException {
    
    User user = new User();
    user.setId(1);
    user.setEmployeeId(1);
    user.setFirstName("Pandurang");
    user.setLastName("Pokharkar");
    
    when(userRepositoryMock.save(any(User.class))).thenReturn(user);
    
    User returned = userServiceMock.create(user);
    verify(userRepositoryMock, times(1)).save(user);

    assertEquals(user, returned);

    
  }

  @Test
  public void findById() throws ParseException {
    
	  	User user = new User();
		user.setId(1);
		user.setEmployeeId(1);
		user.setFirstName("Pandurang");
		user.setLastName("Pokharkar");

    
      when(userRepositoryMock.findOne(1)).thenReturn(user);
      
      User returned = userServiceMock.findById(1);
      
      verify(userRepositoryMock, times(1)).findOne(1);
      verifyNoMoreInteractions(userRepositoryMock);
      
      assertEquals(user, returned);
  }
  

  @Test
  public void findAll() throws ParseException {
    
	  	User user = new User();
		user.setId(1);
		user.setEmployeeId(1);
		user.setFirstName("Pandurang");
		user.setLastName("Pokharkar");
		
		List<User> list = new ArrayList<User>();
		list.add(user);

    
      when(userRepositoryMock.findAll()).thenReturn(list);
      
      List<User> returned = userServiceMock.findAll();
      
      verify(userRepositoryMock, times(1)).findAll();
      verifyNoMoreInteractions(userRepositoryMock);
      
      assertEquals(list, returned);
  }
  
  
  

}
