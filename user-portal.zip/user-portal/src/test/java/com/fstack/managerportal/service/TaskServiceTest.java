package com.fstack.managerportal.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fstack.managerportal.model.ParentTask;
import com.fstack.managerportal.model.Project;
import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.model.User;
import com.fstack.managerportal.repository.TaskRepository;

import junit.framework.Assert;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class TaskServiceTest {
	@InjectMocks
	private TaskServiceImpl taskServiceImpl;

	@Mock
	TaskRepository taskRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("deprecation")

	@Test
	public void saveTask() throws ParseException {
		Mockito.mock(TaskServiceImpl.class);

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(12);
		task.setTaskName("Dev");
		task.setStatus("Completed");

		Project project = new Project();
		project.setProjectId(1);
		project.setPriority(12);
		project.setUserId(1);
		project.setProject("ADD");

		task.setProject(project);

		ParentTask parentTask = new ParentTask();
		parentTask.setParentId(1);
		parentTask.setParentTask("Planning");

		task.setParentTask(parentTask);

		Mockito.when(taskServiceImpl.add(task)).thenReturn(task);
		Assert.assertEquals(1, task.getTaskId());
		Assert.assertEquals(12, task.getPriority());
		Assert.assertEquals("Dev", task.getTaskName());
		Assert.assertEquals("Completed", task.getStatus());

		Assert.assertEquals(1, task.getParentTask().getParentId());

		Assert.assertEquals(1, task.getProject().getProjectId());

	}

	@Test
	public void updateTask() throws ParseException {
		Mockito.mock(TaskServiceImpl.class);

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(12);
		task.setTaskName("Dev");
		task.setStatus("Completed");

		Mockito.when(taskServiceImpl.updateTask(task)).thenReturn(task);
		Assert.assertEquals(1, task.getTaskId());
		Assert.assertEquals(12, task.getPriority());
	}

	@Test
	public void getAllTask() throws ParseException {
		Mockito.mock(TaskServiceImpl.class);

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(12);
		task.setTaskName("Dev");
		task.setStatus("Completed");

		List<Task> list = new ArrayList<Task>();
		list.add(task);

		Mockito.when(taskServiceImpl.getAllTask()).thenReturn(list);
		Assert.assertEquals(1, list.get(0).getTaskId());
		Assert.assertEquals(12, list.get(0).getPriority());
	}

	@Test
	public void sortTaskByStartDate() throws ParseException {
		Mockito.mock(TaskServiceImpl.class);

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(12);
		task.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"));

		Task taskNext = new Task();
		taskNext.setTaskId(1);
		taskNext.setPriority(12);
		taskNext.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"));

		List<Task> list = new ArrayList<Task>();
		list.add(0, task);
		list.add(1, taskNext);

		System.out.println(list.size());

		Mockito.when(taskServiceImpl.sortTaskByStartDate()).thenReturn(list);
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"), list.get(0).getStartDate());
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"), list.get(1).getStartDate());
	}

	@Test
	public void sortTaskByEndDate() throws ParseException {
		Mockito.mock(TaskServiceImpl.class);

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(12);
		task.setEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"));

		Task taskNext = new Task();
		taskNext.setTaskId(1);
		taskNext.setPriority(12);
		taskNext.setEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"));

		List<Task> list = new ArrayList<Task>();
		list.add(0, task);
		list.add(1, taskNext);

		System.out.println(list.size());

		Mockito.when(taskServiceImpl.sortTaskByEndDate()).thenReturn(list);
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"), list.get(0).getEndDate());
		Assert.assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"), list.get(1).getEndDate());
	}

	@Test
	public void sortTaskByPriority() throws ParseException {
		Mockito.mock(TaskServiceImpl.class);

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(11);
		task.setEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("31/12/1998"));

		Task taskNext = new Task();
		taskNext.setTaskId(1);
		taskNext.setPriority(12);
		taskNext.setEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/11/1999"));

		List<Task> list = new ArrayList<Task>();
		list.add(0, task);
		list.add(1, taskNext);

		System.out.println(list.size());

		Mockito.when(taskServiceImpl.sortTaskByPriority()).thenReturn(list);
		Assert.assertEquals(11, list.get(0).getPriority());
		Assert.assertEquals(12, list.get(1).getPriority());
	}

}
