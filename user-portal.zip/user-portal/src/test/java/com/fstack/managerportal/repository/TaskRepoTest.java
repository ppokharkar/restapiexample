package com.fstack.managerportal.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.repository.TaskRepository;
import com.fstack.managerportal.service.TaskServiceImpl;

public class TaskRepoTest {
  
  
  private TaskServiceImpl taskServiceImplMock;

  private TaskRepository taskRepositoryMock;

  @Before
  public void setUp() {
	  taskServiceImplMock = new TaskServiceImpl();
	  taskRepositoryMock = mock(TaskRepository.class);
	  taskServiceImplMock.setTaskRepository(taskRepositoryMock);
  }
  
	@Test
	public void create() throws ParseException {

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(23);
		task.setStatus("Complete");

		when(taskRepositoryMock.save(any(Task.class))).thenReturn(task);

		Task returned = taskServiceImplMock.add(task);
		verify(taskRepositoryMock, times(1)).save(task);

		assertEquals(task, returned);

	}


	@Test
	public void findAll() throws ParseException {

		Task task = new Task();
		task.setTaskId(1);
		task.setPriority(23);
		task.setStatus("Complete");
		List<Task> list = new ArrayList<Task>();
		list.add(task);

		when(taskRepositoryMock.findAll()).thenReturn(list);

		List<Task> returned = taskServiceImplMock.getAllTask();

		verify(taskRepositoryMock, times(1)).findAll();
		verifyNoMoreInteractions(taskRepositoryMock);

		assertEquals(list, returned);
	}
  
  
  

}
