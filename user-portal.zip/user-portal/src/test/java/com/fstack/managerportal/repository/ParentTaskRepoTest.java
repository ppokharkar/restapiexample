package com.fstack.managerportal.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.fstack.managerportal.model.ParentTask;
import com.fstack.managerportal.repository.ParentTaskRepository;
import com.fstack.managerportal.service.ParentTaskServiceImpl;

public class ParentTaskRepoTest {
  
  
  private ParentTaskServiceImpl parentTaskServiceImplMock;

  private ParentTaskRepository parentTaskRepositoryMock;

  @Before
  public void setUp() {
	  parentTaskServiceImplMock = new ParentTaskServiceImpl();
	  parentTaskRepositoryMock = mock(ParentTaskRepository.class);
	  parentTaskServiceImplMock.setTaskRepository(parentTaskRepositoryMock);
  }
  
  @Test
  public void create() throws ParseException {
    
	  ParentTask parentTask = new ParentTask();
	  parentTask.setParentId(1);
	  parentTask.setParentTask("Dev");
    
    
    when(parentTaskRepositoryMock.save(any(ParentTask.class))).thenReturn(parentTask);
    
    ParentTask returned = parentTaskServiceImplMock.add(parentTask);
    verify(parentTaskRepositoryMock, times(1)).save(parentTask);

    assertEquals(parentTask, returned);

    
  }
  

  @Test
  public void findAll() throws ParseException {

	  ParentTask parentTask = new ParentTask();
	  parentTask.setParentId(1);
	  parentTask.setParentTask("Dev");
		
		List<ParentTask> list = new ArrayList<ParentTask>();
		list.add(parentTask);

    
      when(parentTaskRepositoryMock.findAll()).thenReturn(list);
      
      List<ParentTask> returned = parentTaskServiceImplMock.getAllParentTask();
      
      verify(parentTaskRepositoryMock, times(1)).findAll();
      verifyNoMoreInteractions(parentTaskRepositoryMock);
      
      assertEquals(list, returned);
  }
  
  
  

}
