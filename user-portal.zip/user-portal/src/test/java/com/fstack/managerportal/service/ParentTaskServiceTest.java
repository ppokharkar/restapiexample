package com.fstack.managerportal.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fstack.managerportal.model.ParentTask;
import com.fstack.managerportal.model.Task;
import com.fstack.managerportal.model.User;
import com.fstack.managerportal.repository.ParentTaskRepository;

import junit.framework.Assert;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class ParentTaskServiceTest {
  @InjectMocks
   private ParentTaskServiceImpl parentTaskServiceImpl;
  
  @Mock
  ParentTaskRepository parentTaskRepository;
  
  @Before
  public void init() {
      MockitoAnnotations.initMocks(this);
  }
   
   @SuppressWarnings("deprecation")

   @Test
   public void saveParentTask() throws ParseException {
     Mockito.mock(ParentTaskServiceImpl.class);
     ParentTask parentTask = new ParentTask();
     parentTask.setParentId(1);
     parentTask.setParentTask("Planning");
     
     
        Task task = new Task();
		task.setTaskId(1);
		task.setPriority(12);
		task.setTaskName("Dev");
		task.setStatus("Completed");

		List<Task> list = new ArrayList<Task>();
		list.add(0,task);
		
		parentTask.setTask(list);
     
     
      Mockito.when(parentTaskServiceImpl.add(parentTask)).thenReturn(parentTask);
      Assert.assertEquals(1, parentTask.getParentId());
      Assert.assertEquals("Planning", parentTask.getParentTask());
      Assert.assertEquals("Dev", parentTask.getTask().get(0).getTaskName());

   }
   
   
   
	@Test
   public void getAllParentTask() throws ParseException {
	   Mockito.mock(ParentTaskServiceImpl.class);
	     ParentTask parentTask = new ParentTask();
	     parentTask.setParentId(1);
	     parentTask.setParentTask("Planning");
	     
	     ParentTask parentTaskNext = new ParentTask();
	     parentTaskNext.setParentId(2);
	     parentTaskNext.setParentTask("Budgeting");
	     
	     
     
     List<ParentTask> list = new ArrayList<ParentTask>();
     list.add(0,parentTask);
     list.add(1,parentTaskNext);

     
      Mockito.when(parentTaskServiceImpl.getAllParentTask()).thenReturn(list);
      Assert.assertEquals(1, list.get(0).getParentId());
      Assert.assertEquals(2, list.get(1).getParentId());
   }
   
   
}
