import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

import { User } from '../models/user.model';
import { UserService } from '../user/user.service';
import { Project } from '../models/project.model';
import { ProjectService } from '../user/project.service';

@Component({
  selector: 'app-employee',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {

  projects: Project[];
  project: Project = new Project();

constructor(public dialogRef: MatDialogRef<ProjectComponent>,private userService: UserService,private projectService: ProjectService) { }


   ngOnInit() {
    this.projectService.getProjects()
      .subscribe( data => {
        this.projects = data;
	
      });
  };

  onClear() {
    
  }

   onSelect(project: Project):void{

    this.onClose();
  }
      

  onClose() {

    this.dialogRef.close();
  }

}
