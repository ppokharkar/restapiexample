import { Component, OnInit,Inject } from '@angular/core';
import { Router } from '@angular/router';

import { ProjectComponent } from '../project/project.component';
import { ParentTaskComponent } from '../parenttask/parenttask.component';
import { UsersComponent } from '../users/users.component';
import { Task } from '../models/task.model';
import { TaskService } from './task.service';
import { Project } from '../models/project.model';
import { User } from '../models/user.model';
import { ProjectService } from './project.service';
import { UserService } from './user.service';
import * as moment from 'moment';
import { MatDialog, MatDialogConfig } from "@angular/material";


@Component({
  templateUrl: './add-task.component.html'
})
export class AddTaskComponent implements OnInit  {


  tasks: Task[];

  task: Task = new Task();

  constructor(private router: Router, private taskService: TaskService,private projectService: ProjectService, private userService: UserService, private dialog: MatDialog) {

  }

 ngOnInit() {
    this.taskService.getTasks()
      .subscribe( data => {
        this.tasks = data;
	
      });
  };

validateTaskInputs(): boolean{

	if(this.task.taskName==null){
	  alert("Please enter task name");
	  return false;
	}
	if(this.task.startDate==null){
	   alert("Please enter start Date");
	  return false;
	}
	if(this.task.endDate==null){
	   alert("Please enter end date");
	  return false;
	}
	if(this.task.startDate>=this.task.endDate){
	  alert("start date can not greater or equal than end date");
	  return false;
         }
	
	if(this.task.priority==null){
	   alert("Please select priority");
	  return false;
	}
return true;

}

  createTask(): void {
	if(this.validateTaskInputs()){
	alert("inside create task");
	    this.taskService.createTask(this.task)
		.subscribe( data => {
		  alert("Task created successfully.");
		});
	}

  };

 updateTask(): void {
	if(this.validateTaskInputs()){
	    this.taskService.updateTask(this.task)
		.subscribe( data => {
		  alert("Task updated successfully.");
		});

		  this.taskService.getTasks()
	      .subscribe( data => {
		this.tasks = data;
		
	      });
	}

  };


resetTask(){
        this.task.taskName=""; 
	this.task.startDate="";
	this.task.endDate="";
	this.task.priority="";
	this.task.status="";

}
openProject(){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(ProjectComponent,dialogConfig);
  }

openUser(){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(UsersComponent,dialogConfig);
  }

openParentTask(){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(ParentTaskComponent,dialogConfig);
  }

  editTask(task: Task):void{
        this.task.taskId=task.taskId; 
        this.task.taskName=task.taskName; 
	this.task.startDate=moment(task.startDate).format('MM-DD-YYYY');
	this.task.endDate=moment(task.endDate).format('MM-DD-YYYY');
	this.task.priority=task.priority;
	this.task.status=task.status;
	};

  
  
}
