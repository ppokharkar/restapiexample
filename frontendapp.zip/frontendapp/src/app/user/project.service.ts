import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Project } from '../models/project.model';
import { User } from '../models/user.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ProjectService {

  constructor(private http:HttpClient) {}

  private userUrl = '/projects';
  //private userUrl = '/api';

  public getProjects() {
    return this.http.get<Project[]>(this.userUrl+"/projectList");
  }

 public getProject(projectId) {
    return this.http.get<Project>(this.userUrl+"/"+projectId);
  }

  
  public createProject(project) {
    return this.http.post<Project>(this.userUrl, project);
  }

  public updateProject(project) {
    return this.http.put<Project>(this.userUrl, project);
  }

  public sortProjectByStartDate() {
    return this.http.get<Project[]>(this.userUrl+"/sortProjectByStartDate");
  }


public sortTasksByStartDate(projectId) {
    return this.http.get<Project>(this.userUrl+"/sortTasksByStartDate/"+projectId);
  }


public sortTasksByEndDate(projectId) {
    return this.http.get<Project>(this.userUrl+"/sortTasksByEndDate/"+projectId);
  }


public sortTasksByPriority(projectId) {
    return this.http.get<Project>(this.userUrl+"/sortTasksByPriority/"+projectId);
  }

  public sortProjectByEndDate() {
    return this.http.get<Project[]>(this.userUrl+"/sortProjectByEndDate");
  }

  public sortProjectByPriority() {
    return this.http.get<Project[]>(this.userUrl+"/sortProjectByPriority");
  }

 public selectedUser(user){
	return user.userId;
}

}
