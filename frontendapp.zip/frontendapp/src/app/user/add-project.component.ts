import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { EmployeeComponent } from '../employee/employee.component';
import { Project } from '../models/project.model';
import { User } from '../models/user.model';
import { ProjectService } from './project.service';
import { UserService } from './user.service';
import { MatDialog, MatDialogConfig } from "@angular/material";



import * as moment from 'moment';


@Component({
  templateUrl: './add-project.component.html'
})
export class AddProjectComponent implements OnInit  {

  users: User[];	
  projects: Project[];

  project: Project = new Project();

  constructor(private router: Router, private projectService: ProjectService, private userService: UserService, private dialog: MatDialog) {

  }

 ngOnInit() {
    this.projectService.getProjects()
      .subscribe( data => {
        this.projects = data;
	
      });

	
      };


 reloadData() {
    this.projectService.getProjects()
      .subscribe( data => {
        this.projects = data;
	
      });
  }

validateProjectInputs(): boolean{

	if(this.project.projectName==null){
	  alert("Please enter project name");
	  return false;
	}
	if(this.project.startDate==null){
	   alert("Please enter start Date");
	  return false;
	}
	if(this.project.endDate==null){
	   alert("Please enter end date");
	  return false;
	}
	if(this.project.startDate>=this.project.endDate){
	  alert("start date can not greater or equal than end date");
	  return false;
         }
	if(this.project.priority==null){
	   alert("Please select priority");
	  return false;
	}
	if(this.project.userId==null){
	   alert("Please select user Id");
	  return false;
	}

}


  createProject(): void {
   if(this.validateProjectInputs()){
    this.projectService.createProject(this.project)
        .subscribe( data => {
          this.reloadData();
          alert("Project created successfully.");
        });
}

  };

 updateProject(): void {
  if(this.validateProjectInputs()){
    this.projectService.updateProject(this.project)
        .subscribe( data => {
          this.reloadData();
          alert("Project updated successfully.");
        });

	 }
  };

resetProject(): void {

        this.project.projectId=""; 
        this.project.projectName=""; 
	this.project.startDate="";
	this.project.endDate="";
	this.project.priority="";
	this.project.userId=""; 

}

onCreate(){

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(EmployeeComponent,dialogConfig);
  }


  editProject(project: Project):void{
        this.project.projectId=project.projectId; 
        this.project.projectName=project.projectName; 
	this.project.startDate=moment(project.startDate).format('MM-DD-YYYY');
	this.project.endDate=moment(project.endDate).format('MM-DD-YYYY');
	this.project.priority=project.priority;
	this.project.userId=project.userId; 
	};

  
  sortProjectByStartDate(): void {
     this.projectService.sortProjectByStartDate()
      .subscribe( data => {
        this.projects = data;
      })
  };


 
sortProjectByPriority(): void {
     this.projectService.sortProjectByPriority()
      .subscribe( data => {
        this.projects = data;
      })
  };

 
}
