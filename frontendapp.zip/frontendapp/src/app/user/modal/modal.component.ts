import { Component, Input, OnInit } from '@angular/core';

import {NgbModal, NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

import { User } from 'app/models/user.model';
import { UserService } from 'app/user/user.service';


@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {

  @Input() title = `Information`;

  users: User[];

  constructor(public activeModal: NgbActiveModal,private userService: UserService) {}

  ngOnInit() {

this.userService.getUsers()
      .subscribe( data => {
        this.users = data;
alert(this.users);
      });
  }
  }
