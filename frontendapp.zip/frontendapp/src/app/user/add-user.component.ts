import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../models/user.model';
import { UserService } from './user.service';

@Component({
  templateUrl: './add-user.component.html'
})
export class AddUserComponent implements OnInit  {

  users: User[];

  user: User = new User();

  constructor(private router: Router, private userService: UserService) {

  }

 ngOnInit() {
    this.userService.getUsers()
      .subscribe( data => {
        this.users = data;
	
      });
  };

reloadData() {

this.userService.getUsers()
      .subscribe( data => {
        this.users = data;
	
      });

}

  createUser(): void {
	if(this.validateUserInputs()){
	    this.userService.createUser(this.user)
        .subscribe( data => {
          this.reloadData();
          alert("User created successfully.");
        });
}
  };

validateUserInputs(): boolean{

if(this.user.firstName==null){
		alert("Please enter first name");
	return false;
	}
	if(this.user.lastName==null){
	   alert("Please enter last name");
	return false;
	}
	if(this.user.employeeId==null){
	   alert("Please enter Employee Id");
	return false;
	}

}

 updateUser(): void {
if(this.validateUserInputs()){
    this.userService.updateUser(this.user)
        .subscribe( data => {
         this.reloadData();
          alert("User updated successfully.");
        });
}
};

resetUser(): void {

       this.user.id=""; 
	this.user.firstName="";
	this.user.lastName="";
	this.user.employeeId="";
}

  editUser(user: User):void{
        this.user.id=user.id; 
	this.user.firstName=user.firstName;
	this.user.lastName=user.lastName;
	this.user.employeeId=user.employeeId;
	};

  deleteUser(user: User): void {
    this.userService.deleteUser(user)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

  sortUserByFirstName(): void {
     this.userService.sortUserByFirstName()
      .subscribe( data => {
        this.users = data;
      })
  };

sortUserByLastName(): void {
     this.userService.sortUserByLastName()
      .subscribe( data => {
        this.users = data;
      })
  };
sortUserByEmployeeId(): void {
     this.userService.sortUserByEmployeeId()
      .subscribe( data => {
        this.users = data;
      })
  };
  
}
