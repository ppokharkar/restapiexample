import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ProjectComponent } from '../project/project.component';
import { EditTaskComponent } from '../task/edit-task.component';
import { EmployeeComponent } from '../employee/employee.component';
import { Project } from '../models/project.model';
import { User } from '../models/user.model';
import { ProjectService } from './project.service';
import { Task } from '../models/task.model';
import { TaskService } from './task.service';
import { UserService } from './user.service';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { AddTaskComponent } from './add-task.component';



import * as moment from 'moment';


@Component({
  templateUrl: './viewtask.component.html'
})
export class ViewTaskComponent implements OnInit  {

  users: User[];	
  projects: Project[];
  tasks: Task[];

  task: Task = new Task();

  project: Project = new Project();

  constructor(private router: Router, private taskService: TaskService,private projectService: ProjectService, private userService: UserService, private dialog: MatDialog) {

  }

 ngOnInit() {
    
};

getProject(): void {



};

openProject(){



    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(ProjectComponent,dialogConfig);

    this.projectService.getProject(this.project.projectId)
      .subscribe( data => {
        this.project = data;
	
      });
  };


 updateTask(): void {
    this.taskService.updateTask(this.task)
        .subscribe( data => {
          alert("Task updated successfully.");
        });


  };
  onEdit(row){
    this.taskService.populateForm(row);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(EditTaskComponent,dialogConfig);
  }

 sortTasksByStartDate(): void {
     this.projectService.sortTasksByStartDate(this.project.projectId)
      .subscribe( data => {
        this.project = data;
      })
  };


 sortTasksByEndDate(): void {
     this.projectService.sortTasksByEndDate(this.project.projectId)
      .subscribe( data => {
        this.project = data;
      })
  };


sortTasksByPriority(): void {
     this.projectService.sortTasksByPriority(this.project.projectId)
      .subscribe( data => {
        this.project = data;
      })
  };

  

sortTasksByCompletedStatus(): void {
     this.taskService.sortTaskByCompletedStatus()
      .subscribe( data => {
        this.tasks = data;
      })
  };

 
}
