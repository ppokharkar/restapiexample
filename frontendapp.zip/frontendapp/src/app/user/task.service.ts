import {Injectable} from '@angular/core';
import { FormGroup, FormControl, Validators,FormBuilder } from "@angular/forms";
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Task } from '../models/task.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class TaskService {

  constructor(private http:HttpClient,    private fb: FormBuilder) {}



form: FormGroup = new FormGroup({
    projectId: new FormControl('', Validators.required),
    projectName: new FormControl('', Validators.required),
    startDate: new FormControl('', Validators.required),
    endDate: new FormControl('', Validators.required),
    priority: new FormControl('', Validators.required),
    userId: new FormControl('', Validators.required),
    task: new FormControl('', Validators.required)
   
  });

  private userUrl = '/tasks';
  //private userUrl = '/api';

  public getTasks() {
    return this.http.get<Task[]>(this.userUrl+"/taskList");
  }

  
  public createTask(task) {
	alert("inside create taskservice "+this.userUrl );
    return this.http.post<Task>(this.userUrl, task);
  }

  public updateTask(task) {
    return this.http.put<Task>(this.userUrl, task);
  }

  public sortTaskByEndDate() {
    return this.http.get<Task[]>(this.userUrl+"/sortTaskByEndDate");
  }

  public sortTaskByPriority() {
    return this.http.get<Task[]>(this.userUrl+"/sortTaskByPriority");
  }

  public sortTaskByCompletedStatus() {
    return this.http.get<Task[]>(this.userUrl+"/sortTaskByCompletedStatus");
  }

populateForm(project) {
    this.form.setValue(project);
  }

}
