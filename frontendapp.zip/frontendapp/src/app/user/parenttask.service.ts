import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { ParentTask } from '../models/parenttask.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ParentTaskService {

  constructor(private http:HttpClient) {}

  private userUrl = '/parenttasks';
  //private userUrl = '/api';

  public getParentTasks() {
    return this.http.get<ParentTask[]>(this.userUrl+"/parenttaskList");
  }

  
  public createParentTask(parenttask) {
    return this.http.post<ParentTask>(this.userUrl, parenttask);
  }

   public updateParentTask(parenttask) {
    return this.http.put<ParentTask>(this.userUrl, parenttask);
  }

 }
