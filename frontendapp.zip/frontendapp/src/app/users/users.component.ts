import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

import { User } from '../models/user.model';
import { UserService } from '../user/user.service';
import { Project } from '../models/project.model';
import { ProjectService } from '../user/project.service';

@Component({
  selector: 'app-employee',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  users: User[];

constructor(public dialogRef: MatDialogRef<UsersComponent>,private userService: UserService,private projectService: ProjectService) { }


   ngOnInit() {
    this.userService.getUsers()
      .subscribe( data => {
        this.users = data;
	
      });
  };

  onClear() {
    
  }

   openUserDialog(user: User):void{

    this.onClose();
  }
      

  onClose() {

    this.dialogRef.close();
  }

}
