import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

import { TaskService } from '../user/task.service';
import { ProjectService } from '../user/project.service';

@Component({
  selector: 'app-employee',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  constructor(private service: TaskService,
    private projectService: ProjectService,
    public dialogRef: MatDialogRef<EditTaskComponent>) { }



  ngOnInit() {
    //this.service.getEmployees();
  }

  onClear() {
    /*this.service.form.reset();
    this.service.initializeFormGroup();
    this.notificationService.success(':: Submitted successfully');*/
  }

  onSubmit() {
   /* if (this.service.form.valid) {
      if (!this.service.form.get('$key').value)
        this.service.insertEmployee(this.service.form.value);
      else
      this.service.updateEmployee(this.service.form.value);
      this.service.form.reset();
      this.service.initializeFormGroup();
      this.notificationService.success(':: Submitted successfully');
      this.onClose();
    }*/
  }

  onClose() {
    /*this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close();*/
  }

}
