import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule,FormsModule } from "@angular/forms";


import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { ViewTaskComponent } from './user/viewtask.component';
import { EditTaskComponent } from './task/edit-task.component';
import { AppRoutingModule } from './app.routing.module';
import {UserService} from './user/user.service';
import {ProjectService} from './user/project.service';
import { ParentTaskService } from './user/parenttask.service';
import {HttpClientModule} from "@angular/common/http";
import {AddUserComponent} from './user/add-user.component';
import {AddProjectComponent} from './user/add-project.component';
import {AddTaskComponent} from './user/add-task.component';
import {TaskService} from './user/task.service';
import { EmployeeComponent } from './employee/employee.component';
import { ProjectComponent } from './project/project.component';
import { UsersComponent } from './users/users.component';
import { ParentTaskComponent } from './parenttask/parenttask.component';
import { MaterialModule } from "./material/material.module";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';




@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    AddUserComponent,
    AddProjectComponent,
    ParentTaskComponent,
    AddTaskComponent,
    EmployeeComponent,
    ProjectComponent,
    ViewTaskComponent,	
    EditTaskComponent,
    UsersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    MaterialModule,
    FormsModule
  ],
  providers: [UserService,ProjectService,TaskService,ParentTaskService],
  bootstrap: [AppComponent],
  entryComponents:[EmployeeComponent,UsersComponent,ProjectComponent,ParentTaskComponent,EditTaskComponent]

})
export class AppModule { }
