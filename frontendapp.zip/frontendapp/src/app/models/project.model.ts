import { Task } from '../models/task.model';


export class Project {

  projectId: string;
  projectName: string;
  startDate: string;
  endDate: string;
  priority: string; 
  userId: string;
  task: Task[];
}
