import { Task } from '../models/task.model';
export class ParentTask {

  parentId: string;
  parentTask: string;
  task: Task[];
 }
