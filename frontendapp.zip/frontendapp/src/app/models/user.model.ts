export class User {

  id: string;
  firstName: string;
  lastName: string;
  employeeId: string;
}
