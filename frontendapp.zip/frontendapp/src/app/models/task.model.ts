import { Project } from '../models/project.model';
import { ParentTask } from '../models/parenttask.model';
export class Task {

  taskId: string;
  taskName: string;
  startDate: string;
  endDate: string;
  priority: string; 
  status: string;
  project: Project;
  parentTask: ParentTask 
}
