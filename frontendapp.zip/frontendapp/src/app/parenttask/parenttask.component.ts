import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

import { ParentTask } from '../models/parenttask.model';
import { ParentTaskService } from '../user/parenttask.service';


@Component({
  selector: 'app-employee',
  templateUrl: './parenttask.component.html',
  styleUrls: ['./parenttask.component.css']
})
export class ParentTaskComponent implements OnInit {

  parentTasks: ParentTask[];
  parentTask: ParentTask = new ParentTask();

constructor(public dialogRef: MatDialogRef<ParentTaskComponent>,private parentTaskService: ParentTaskService) { }


   ngOnInit() {
    this.parentTaskService.getParentTasks()
      .subscribe( data => {
        this.parentTasks = data;

      });
  };

  onClear() {
    
  }

   openUserDialog(parentTask: ParentTask):void{

    this.onClose();
  }
      

  onClose() {

    this.dialogRef.close();
  }

}
