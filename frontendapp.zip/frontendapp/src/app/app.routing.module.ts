import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddProjectComponent } from './user/add-project.component';
import { AddTaskComponent } from './user/add-task.component';
import {AddUserComponent} from './user/add-user.component';
import { ViewTaskComponent } from './user/viewtask.component';

const routes: Routes = [
  { path: 'addProject', component: AddProjectComponent },
  { path: 'addTask', component: AddTaskComponent },
  { path: 'add', component: AddUserComponent },
  { path: 'viewTask', component: ViewTaskComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
