import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

import { User } from '../models/user.model';
import { UserService } from '../user/user.service';
import { Project } from '../models/project.model';
import { ProjectService } from '../user/project.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  users: User[];
  user: User = new User();
  project: Project = new Project();

constructor(public dialogRef: MatDialogRef<EmployeeComponent>,private userService: UserService,private projectService: ProjectService) { }


   ngOnInit() {
    this.userService.getUsers()
      .subscribe( data => {
        this.users = data;
	
      });
  };

  onClear() {
    
  }

   onSelect(user: User):void{

    this.onClose();
  }
      

  onClose() {

    this.dialogRef.close();
  }

}
